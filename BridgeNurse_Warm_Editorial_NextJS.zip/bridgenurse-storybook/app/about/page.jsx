import StorySite from '../../components/StoryUI';
export const metadata={title:'About us',description:'Meet BridgeNurse by Triple Arrow Global, and learn about our promises to nurses and caregivers exploring fair international careers.'};
export default function AboutPage(){return <StorySite page="about"/>}
