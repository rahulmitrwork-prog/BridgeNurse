import {NextResponse} from 'next/server';
export const runtime='nodejs';
export const dynamic='force-dynamic';
const json=(body,status)=>NextResponse.json(body,{status,headers:{'Cache-Control':'no-store'}});
export async function POST(req){
 const endpoint=process.env.WAITLIST_WEBHOOK_URL;
 if(!endpoint)return json({error:'Waitlist endpoint is not configured.'},503);
 let url;
 try{url=new URL(endpoint);if(url.protocol!=='https:')throw new Error('HTTPS required')}catch{return json({error:'Invalid waitlist endpoint configuration.'},503)}
 let body;
 try{body=await req.json()}catch{return json({error:'Invalid JSON.'},400)}
 const {name,email,stage='',website=''}=body??{};
 if(website)return json({ok:true},200); // honeypot: silently discard bot submissions
 if(typeof name!=='string'||!name.trim()||name.length>100||typeof email!=='string'||email.length>254||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()))return json({error:'Invalid name or email.'},400);
 if(!['','exploring','learning','ready'].includes(stage))return json({error:'Invalid stage.'},400);
 const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),10000);
 try{
  const headers={'Content-Type':'application/json'};
  if(process.env.WAITLIST_WEBHOOK_TOKEN)headers['Authorization']=`Bearer ${process.env.WAITLIST_WEBHOOK_TOKEN}`;
  const result=await fetch(url,{method:'POST',body:JSON.stringify({name:name.trim(),email:email.trim().toLowerCase(),stage,source:'BridgeNurse website',createdAt:new Date().toISOString()}),headers,signal:controller.signal,cache:'no-store'});
  if(!result.ok)return json({error:'Registration temporarily unavailable.'},502);
  return json({ok:true},200);
 }catch{return json({error:'Registration temporarily unavailable.'},502)}finally{clearTimeout(timeout)}
}
