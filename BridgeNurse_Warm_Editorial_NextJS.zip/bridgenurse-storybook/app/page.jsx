import StorySite from '../components/StoryUI';
export default function Home(){return <StorySite page="home"/>}
