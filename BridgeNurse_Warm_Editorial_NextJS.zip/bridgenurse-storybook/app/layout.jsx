import {Instrument_Serif, Geist} from 'next/font/google';
import './globals.css';

// next/font downloads and self-hosts the fonts at build time, emits preloaded
// WOFF2 files, and applies font-display: swap. No font assets are shipped here.
const instrument = Instrument_Serif({subsets:['latin'],weight:['400'],style:['normal','italic'],variable:'--font-instrument',display:'swap',preload:true});
const geist = Geist({subsets:['latin'],variable:'--font-geist',display:'swap',preload:true});
export const metadata={
 metadataBase:new URL('https://bridgenurse.com'),
 title:{default:'BridgeNurse | A fairer pathway to nursing careers abroad',template:'%s | BridgeNurse'},
 description:'BridgeNurse supports nurses and caregivers exploring opportunities in Germany and Japan. Learn about fee-free preparation, transparent recruitment, and support after arrival.',
 openGraph:{type:'website',siteName:'BridgeNurse',title:'BridgeNurse — Your caring career can travel further',description:'A fairer, transparent journey toward nursing and care careers in Germany and Japan.',images:[{url:'/opengraph-image.png',width:1200,height:630,alt:'BridgeNurse — nursing careers abroad'}]},
 twitter:{card:'summary_large_image',title:'BridgeNurse — Your next chapter in care',description:'Fee-free preparation. Transparent pathways. Support after arrival.',images:['/opengraph-image.png']},
 robots:{index:true,follow:true},
};
export const viewport={width:'device-width',initialScale:1,themeColor:'#FFF5E6'};
export default function RootLayout({children}){return <html lang="en"><body className={`${instrument.variable} ${geist.variable}`}>{children}</body></html>}
