# BridgeNurse — Warm Editorial Storybook

A complete Next.js App Router implementation of the BridgeNurse website in the "Warm Editorial Storybook SaaS" design language. Designed for Vercel. Contains a homepage and About page, original SVG illustration assets, a responsive floating navigation, five-language content drawn from the supplied site, story carousel, interactive 3D pathway cards, dark-panel animated canvas starfield, original guide mascot with eye tracking, an accessible FAQ, and a simplified waitlist form.

## Start

```sh
npm install
cp .env.example .env.local
npm run dev
```

Visit `http://localhost:3000`. For production, set up the environment variables below and use `npm run build`, or deploy the folder on Vercel as a Next.js project.

The page uses `next/font/google` for Instrument Serif and Geist; during builds Next downloads these fonts, emits self-hosted WOFF2 and preload tags. **The source archive deliberately does not include font files**. Building the first time requires network access to Google Fonts through Next's font loader.

## Connect the waitlist

Set `WAITLIST_WEBHOOK_URL` to an HTTPS endpoint under your control that accepts the following JSON:

```json
{"name":"First Last","email":"name@example.com","stage":"exploring","source":"BridgeNurse website","createdAt":"2026-10-15T00:00:00.000Z"}
```

Optionally set `WAITLIST_WEBHOOK_TOKEN` for `Authorization: Bearer …`. The Next.js server action `/api/waitlist` validates names, email, and stage; does not relay payloads when the endpoint is missing; and uses a 10-second timeout. The form does not display a fake success when submissions cannot reach the configured service. Add spam/abuse throttling at your webhook or edge service before large-scale production deployment, and verify data/privacy compliance requirements with your own legal advisor. Do not expose the token through NEXT_PUBLIC variables.

## Design and content

- Theme palette: cream #FFF5E6, paper #FFFBF4, sage #DCE9DF, violet #4F309C, dark ink #161C32.
- Fonts: Instrument Serif + Geist via next/font. CSS only; no Tailwind and no animation libraries.
- Accessibility: visible keyboard focus, skip link, semantic landmarks, accessible interaction labels, reduced-motion accommodation, and appropriate alt text for artwork.
- Original content: `content/sourceTranslations.json` preserves translated text from the supplied BridgeNurse website in English, Hindi, Indonesian, Bengali, and Tamil. New UI labels have corresponding translations in `components/StoryUI.jsx`. Company contact details are intentionally not invented.
- Illustrations in `/public/illustrations` are original SVG assets created for this redesign.
- SEO metadata is in `app/layout.jsx` and `app/about/page.jsx`. Change `metadataBase` when deploying to a different domain. A project-specific social-sharing image can optionally be added to `public` when approved.
- The waitlist is **not a job offer**; the source content and disclaimer preserve that distinction.

## Pages

- `/` — narrative landing page, with hero, audience, stakes, four-chapter story, three-step 3D process, commitments, FAQ, conversion form, and footer.
- `/about` — sticky-left editorial layout explaining the team, recruitment promise, safety, and destination routes.
